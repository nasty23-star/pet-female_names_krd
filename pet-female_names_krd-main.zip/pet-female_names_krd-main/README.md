# pet-female_names_krd
pet project, female names in the map of krasnodar, russia
